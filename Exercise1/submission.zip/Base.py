class BaseLayer():
    def __init__(self) -> None:
        """Constructor of the Base Layer
        """
        self.trainable = False